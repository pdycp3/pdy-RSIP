﻿#include "SARibbonComboBox.h"


SARibbonComboBox::SARibbonComboBox(QWidget *parent)
    : QComboBox(parent)
{
}

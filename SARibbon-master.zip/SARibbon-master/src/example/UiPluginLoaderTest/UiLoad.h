﻿#ifndef UILOAD_H
#define UILOAD_H
#include <QWidget>


QWidget* load();

#endif // UILOAD_H

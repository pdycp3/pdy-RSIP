# 使用designer的方法

编译*DesignerPlugin*